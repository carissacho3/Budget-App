const express = require("express");
const app = express();
const HTTP_PORT = process.env.PORT || 3030;

// use a static resources folder
app.use(express.static("stuff"));

// configure express to receive form field data
app.use(express.urlencoded({ extended: true }));

// setup handlebars
const exphbs = require("express-handlebars");
app.engine(
  ".hbs",
  exphbs.engine({
    extname: ".hbs",
    helpers: {
      json: (context) => {
        return JSON.stringify(context);
      },
    },
  })
);

app.set("view engine", ".hbs");

const mongoose = require("mongoose");
// TODO: Replace this with your mongodb connection string
// The mongodb connection string is in the MongoAtlas web interface
mongoose.connect(
  "mongodb+srv://web322:fl9SHrBOnQNdZ9sM@cluster0.y5dzql0.mongodb.net/?retryWrites=true&w=majority"
);

// setup session
const session = require("express-session");
app.use(
  session({
    secret: "the quick brown fox jumped over the lazy dog 1234567890", // random string, used for configuring the session
    resave: false,
    saveUninitialized: true,
  })
);

const bcrypt = require("bcryptjs");

const Schema = mongoose.Schema;

const userSchema = new Schema({ username: String, password: String });
const Users = mongoose.model("users_collection", userSchema);

const financeSchema = new Schema({
  budget: Number,
  spent: Number,
  username: String,
});
const Finance = mongoose.model("finance_collection", financeSchema);

const expenseSchema = new Schema({
  name: String,
  desc: String,
  price: Number,
  username: String,
});
const Expense = mongoose.model("expense_collection", expenseSchema);

// endpoints
app.get("/", async (req, res) => {
  return res.render("login", { layout: "nav" });
});

app.post("/login", async (req, res) => {
  const usernameUI = req.body.username;
  const passwordUI = req.body.password;
  const buttonUI = req.body.option;

  // console.log(req.body);
  // console.log(buttonUI);

  if (buttonUI === "Login") {
    //res.send('The login button value was received successfully!');
    try {
      const userFromDB = await Users.findOne({ username: usernameUI });
      //console.log(usernameUI)

      if (userFromDB === null) {
        req.session.hasLoggedInUser = false;
        return res.render("error", {
          layout: "nav",
          message: `Sorry but ${usernameUI} doesn't exist`,
          log: req.session.hasLoggedInUser,
        });
        // return res.send(`ERROR: ${usernameUI} DOESN'T EXIST`);
      } else {
        const isPasswordSame = await bcrypt.compare(
          passwordUI,
          userFromDB.password
        );
        if (isPasswordSame == true) {
          req.session.hasLoggedInUser = true;
          req.session.username = userFromDB.username;
          console.log(req.session);
          res.redirect("/profile");
        } else {
          req.session.hasLoggedInUser = false;
          return res.render("error", {
            layout: "nav",
            message: `Sorry but password is in correct`,
            log: req.session.hasLoggedInUser,
          });
        }
      }
    } catch (err) {
      console.log(err);
    }
  } else if (buttonUI === "Create Account") {
    //res.send('The create button value was received successfully!');
    try {
      const userFromDB = await Users.findOne({ username: usernameUI });
      //console.log(usernameUI);

      if (userFromDB != null) {
        req.session.hasLoggedInUser = false;
        return res.render("error", {
          layout: "nav",
          message: `Sorry but ${usernameUI} already exist`,
          log: req.session.hasLoggedInUser,
        });
      } else {
        const hashedPassword = await bcrypt.hash(passwordUI, 10);

        const createUser = new Users({
          username: usernameUI,
          password: hashedPassword,
        });
        await createUser.save();

        const createFinance = new Finance({
          budget: 0,
          remaining: 0,
          spent: 0,
          username: usernameUI,
        });

        await createFinance.save();

        req.session.hasLoggedInUser = true;
        req.session.username = usernameUI;
        console.log(req.session);
        res.redirect("/profile");
      }
    } catch (err) {
      console.log(err);
    }
  }
});

app.get("/profile", async (req, res) => {

  if (req.session.hasLoggedInUser === undefined)
  {
    return res.render("error", { layout: "nav",message: `Sorry but you must be logged in!`  });
  }
  else{
    try {
      const userFromFinance = await Finance.findOne({
        username: req.session.username,
      }).lean();
  
      const userFromExpense = await Expense.find({username: req.session.username}).lean()
      //console.log(userFromFinance);
      return res.render("profile", {
        layout: "nav",
        log: req.session.hasLoggedInUser,
        fine: userFromFinance,
        expenses: userFromExpense,
        update: false,
      });
    } catch (err) {
      console.log(err);
    }
  }
 
});

app.get("/updateBudget", async (req, res) => {
  return res.render("profile", {
    layout: "nav",
    log: req.session.hasLoggedInUser,
    update: true,
  });
});

app.post("/updating", async (req, res) => {
  const budgetUI = parseFloat(req.body.budget);
  // console.log(budgetUI);
  // console.log(req.session.username)
  try {
    const userFromDB = await Finance.findOne({
      username: req.session.username,
    });
    //console.log(userFromDB);
    userFromDB.budget = budgetUI;
    await userFromDB.save();

    res.redirect("/profile");
  } catch (err) {
    console.log(err);
  }
});

app.post("/add", async (req, res) => {
  res.render("addExpense", { layout: "nav" });
});

app.post("/addExpense", async (req, res) => {
  const nameUI = req.body.name;
  const descUI = req.body.desc;
  const priceUI = parseFloat(req.body.price);
  // console.log(nameUI)
  // console.log(descUI)
  // console.log(priceUI)

try {
  const createExpense = new Expense({
    name: nameUI,
    desc: descUI,
    price: priceUI,
    username: req.session.username,
  });

  await createExpense.save();

  const updateTotalSpent = await Finance.findOne({
    username: req.session.username,
  });
  
  updateTotalSpent.spent += priceUI;

  await updateTotalSpent.save();

  res.redirect("/profile");
} catch (err) {
  console.log(err);
}
 
});

app.post("/delete/:id", async (req, res) => {
  const idUI = req.params.id;
  console.log(idUI);

try {
  const findId = await Expense.findOne({_id:idUI});
 
  const userFromFinance = await Finance.findOne({
    username: req.session.username,
  });
  userFromFinance.spent -= findId.price;
  await userFromFinance.save();

  await Expense.deleteOne({_id:idUI});
  
  res.redirect("/profile");


} catch (err) {
  console.log(err);
}
 
});

app.get("/error", (req, res) => {
  let errorMessage = req.query.message;
  res.render("error", { layout: "default", message: errorMessage });
});

app.get("/logout", (req, res) => {
  req.session.destroy();

  console.log(`Session destroyed...`);
  console.log(req.session);

  //res.send("You are logged out");
  res.redirect("/");
});

// start server
const onHttpStart = () => {
  console.log("Express http server listening on: " + HTTP_PORT);
  console.log(`http://localhost:${HTTP_PORT}`);
};
app.listen(HTTP_PORT, onHttpStart);
